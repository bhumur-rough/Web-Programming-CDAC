var fs = require("fs")
let data = fs.readFileSync("QuesB3_Read.txt").toString()
console.log(data)