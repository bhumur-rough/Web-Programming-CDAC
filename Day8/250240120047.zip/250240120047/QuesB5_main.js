var greet = require("./QuesB5_Greeting.js")
console.log(greet.greeting());